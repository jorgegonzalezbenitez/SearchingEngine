import sys
import time
import threading
from SearchingEngine.Crawler.crawler import crawler
from SearchingEngine.Indexer.jsonIndexer import *
from SearchingEngine.Indexer.mongoIndexer import *
from userQuery import *

db_name = "BooksDatabase"
collection_name = "InvertedIndex"

stop_event = threading.Event()


def process_books():
    while not stop_event.is_set():
        crawler()

        dictionary = indexer_json(sys.argv[1])

        save_inverted_index_json(dictionary, sys.argv[2])

        # Conectar a la colección de MongoDB
        mongo_client, collection = set_connection(db_name, collection_name)

        try:
            # Construir el índice invertido en MongoDB
            dictionary = read_words_from_datalake(sys.argv[1])
            build_and_store_inverted_index(dictionary,db_name,collection_name)

        finally:
            # Cerrar la conexión con MongoDB una vez finalizado el proceso
            mongo_client.close()

        # Esperar antes de volver a ejecutar el proceso
        time.sleep(15)

# Función para permitir al usuario hacer consultas en el datamart de MongoDB
def user_query():
    while True:
        # Preguntar si el usuario desea hacer una consulta
        command = input("Escribe 'consultar' para buscar una palabra o 'salir' para terminar el programa: ").strip().lower()

        if command == "consultar":
            word = input("¿Qué palabra deseas buscar? ").strip()

            # Conectar a MongoDB para realizar la consulta
            mongo_client, collection = set_connection(db_name, collection_name)

            try:
                results = search_in_mongo_datamart(collection, word)
                print(results)
            finally:
                # Cerrar la conexión con MongoDB después de realizar la consulta
                mongo_client.close()

        elif command == "salir":
            print("Terminando el programa...")
            stop_event.set()  # Indicar que el hilo de procesamiento debe detenerse
            break

        else:
            print("Comando no reconocido. Intenta de nuevo.")

if __name__ == "__main__":
    book_thread = threading.Thread(target=process_books)
    query_thread = threading.Thread(target=user_query)

    book_thread.start()
    query_thread.start()

    query_thread.join()
    book_thread.join()

    print("The program has finished")